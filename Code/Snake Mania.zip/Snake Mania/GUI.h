#ifndef GUI_H_INCLUDED
#define GUI_H_INCLUDED
#include "windows.h"
#include<stdio.h>

void GetFrame()
{
    int i;
printf("\t_________________________________________________________________________");
for(i=0;i<20;i++)
printf("\n\t||                                                          |            ||");
printf("\n\t||__________________________________________________________|____________||");
}
#endif // GUI_H_INCLUDED
